package com.example.MedicineManagementSystemdemo.exception;

//package com.example.MedicineManagementdemo.exception;

public class CustomerNotFoundException extends Exception {

	public CustomerNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
