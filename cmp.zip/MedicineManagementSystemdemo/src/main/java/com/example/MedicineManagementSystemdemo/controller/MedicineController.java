package com.example.MedicineManagementSystemdemo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MedicineManagementSystemdemo.entity.Medicine;
import com.example.MedicineManagementSystemdemo.exception.MedicineNotFoundException;
import com.example.MedicineManagementSystemdemo.model.MedicineInputModel;
import com.example.MedicineManagementSystemdemo.model.MedicineModel;
import com.example.MedicineManagementSystemdemo.model.MedicineOutputModel;
import com.example.MedicineManagementSystemdemo.service.CustomerService;
import com.example.MedicineManagementSystemdemo.service.MedicineService;

@RestController
@CrossOrigin("http://localhost:3000/")
public class MedicineController {
	
	private final Logger logger=LoggerFactory.getLogger(MedicineController.class);
	
	@Autowired
	MedicineService medicineService;
	
	@PostMapping(value ="/addmedicine")
	public Medicine addMedicine(@RequestBody MedicineInputModel medicineInputModel)  {
		logger.info("Adding medicines");
		Medicine medicine=medicineService.addMedicine(medicineInputModel);
		logger.info("Getting Medicines ");
		return medicine;
	}
	
	@PutMapping(value="/updatemedicine/{mid}")
	public Medicine updateMedicine(@RequestBody Medicine medicine,@PathVariable int mid) throws MedicineNotFoundException
	{
        logger.info("updating medicines by id :{}",mid);
		Medicine newMedicine=medicineService.updateMedicine(medicine,mid);
		logger.info("Medicine updated");
		return newMedicine;
		
	}

	
	@GetMapping(value="/getmedicinebyid/{mid}")
	public MedicineModel viewMedicineById(@PathVariable("mid") int mid) throws MedicineNotFoundException 
	{
		logger.info("viewMedicine() method working");
		return medicineService.viewMedicineById(mid);
		
	}
	
	@GetMapping(value="/getallmedicine")
	public List<MedicineModel> getAllMedicine(){
		logger.info("getMedicine() method working");
		return medicineService.getAllMedicine();
	}
	@DeleteMapping(value="/delete/{id}")
	public void removeMedicineById(int mid) throws MedicineNotFoundException
	{
		medicineService.removeMedicineById(mid);
	}
	
//	@DeleteMapping(value="/deletebymedicinename/{medicinename}")
//	public Medicine deleteByMedicineName(@PathVariable("medicineName") Medicine medicineName){
//		logger.info("deleteByMedicineName() method working");
//		return medicineService.deleteByMedicineName(medicineName);
//	}
	
}



//@GetMapping(value="/getmedicinebyid/{id}")
//public MedicineModel getMedicineById(@PathVariable("id") int mid) throws MedicineNotFoundException {
//	logger.info("getMedicineId() method working");
//	return medicineService.getMedicineById(mid);
//}
//@PostMapping(value ="/addmedicine")
//public MedicineModel addMedicine(@RequestBody Medicine medicine) {
//	logger.info("addMedicine() method starts");
//	medicine=medicineService.addMedicine(medicine);
//	logger.info("addMedicine() method ends");
//	return medicine;
//}
