package com.example.MedicineManagementSystemdemo.model;

//package com.example.MedicineManagementdemo.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
public class OrderedModel {
	
	
	private int quantity;
    private int customerId;
    private String orderType;
    private int mid;
    

	
    
	
	
}

