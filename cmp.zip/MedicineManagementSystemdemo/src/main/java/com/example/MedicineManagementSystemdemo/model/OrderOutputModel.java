package com.example.MedicineManagementSystemdemo.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
public class OrderOutputModel {
	
	private int orderId;
	private LocalDate orderedDate;
	private LocalDate deliveryDate;
	private int quantity;
	private String orderType;
	private double price;
	private int customerId;
	private int mid;
	
	
	

	
}
