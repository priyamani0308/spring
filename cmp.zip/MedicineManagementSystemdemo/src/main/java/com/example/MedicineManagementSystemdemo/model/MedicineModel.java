package com.example.MedicineManagementSystemdemo.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class MedicineModel {

	private int mid;
	private String medicineName;
	private double price;
	private int stock;
	
	
	
	
	
	}
