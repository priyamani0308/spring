package com.example.MedicineManagementSystemdemo.model;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
public class ApiResponseError {

	        private String statusCode;
			public String getStatusCode() {
				return statusCode;
			}
			public void setStatusCode(String statusCode) {
				this.statusCode = statusCode;
			}
			public String getMessage() {
				return message;
			}
			public void setMessage(String message) {
				this.message = message;
			}
			public LocalDateTime getTimeStamp() {
				return TimeStamp;
			}
			public void setTimeStamp(LocalDateTime timeStamp) {
				TimeStamp = timeStamp;
			}
			private String message;
			private LocalDateTime TimeStamp;
		
		
}
