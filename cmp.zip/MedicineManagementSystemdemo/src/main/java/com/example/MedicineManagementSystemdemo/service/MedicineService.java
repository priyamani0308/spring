package com.example.MedicineManagementSystemdemo.service;

import java.util.ArrayList;

//package com.example.MedicineManagementSystemdemo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MedicineManagementSystemdemo.entity.Customer;
import com.example.MedicineManagementSystemdemo.entity.Medicine;
import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.MedicineNotFoundException;
import com.example.MedicineManagementSystemdemo.model.MedicineInputModel;
import com.example.MedicineManagementSystemdemo.model.MedicineModel;
import com.example.MedicineManagementSystemdemo.model.MedicineOutputModel;
import com.example.MedicineManagementSystemdemo.repository.MedicineRepository;


@Service
public class MedicineService {
	
	private final Logger logger=LoggerFactory.getLogger(MedicineService.class);
	
	@Autowired
	MedicineRepository medicineRepository;
	
	
    public Medicine addMedicine(MedicineInputModel medicineInputModel){
		logger.info("addMedicine() method starts");
		Medicine medicine=new Medicine();
		medicine.setMid(medicineInputModel.getMid());
		medicine.setMedicineName(medicineInputModel.getMedicineName());
		medicine.setPrice(medicineInputModel.getPrice());
		medicine.setStock(medicineInputModel.getStock());
		medicine = medicineRepository.save(medicine);
		logger.info("addMedicine() method ends()");
		return medicine;
	}
		
	public MedicineModel viewMedicineById(int mid) throws MedicineNotFoundException 
	{
		logger.info("viewMedicineById method starts()");
		Medicine medicine=medicineRepository.findById(mid).orElse(null);
		if(medicine==null)
		{
			logger.error("Medicines are not found in Id:{}",mid);
			throw new MedicineNotFoundException("medicine not found");
		}
			logger.error("Medicines are :{}", mid);
		MedicineModel model=new MedicineModel();
		model.setMid(medicine.getMid());
		model.setMedicineName(medicine.getMedicineName());
		model.setPrice(medicine.getPrice());
		model.setStock(medicine.getStock());
		logger.info("viewMedicineById method ends()");
		return model;
	}
	

     public void updateStock(int mid, int updatedStock) throws MedicineNotFoundException {
		// TODO Auto-generated method stub
		logger.info("updateStock() method starts");
		Medicine medicine= medicineRepository.findById(mid).orElse(null);
		if(medicine==null) 
			throw new MedicineNotFoundException("Product not Found");
		medicine.setStock(updatedStock);
		medicineRepository.save(medicine);
		logger.info("updateStock() method ends");
	}
	
	public Medicine updateMedicine(Medicine medicine,int mid) throws MedicineNotFoundException 
	{
		logger.info("updateMedicine() method starts");
		Medicine existingMedicine=medicineRepository.getReferenceById(mid);
		if(existingMedicine==null)
		{
			throw new MedicineNotFoundException("Medicine Not Found");
		}
		existingMedicine.setMid(medicine.getMid());
		existingMedicine.setMedicineName(medicine.getMedicineName());
		existingMedicine.setPrice(medicine.getPrice());
		logger.info("updateMedicine() method starts");
		return medicineRepository.save(existingMedicine);
		
	}
	
	public void removeMedicineById(int mid) throws MedicineNotFoundException
	{
		Medicine medicine=medicineRepository.findById(mid).orElse(null);
		if(medicine==null)
		     throw new MedicineNotFoundException("Medicine Not Found");
		else
			medicineRepository.deleteById(mid);
			
		
	}
	
	public List<MedicineModel> getAllMedicine(){
		logger.info("getAllMedicine() method start()");
		List<Medicine> medicineList=medicineRepository.findAll();
		logger.info("medicines are {}", medicineList.size());
		List<MedicineModel> medicineModel= new ArrayList<>();
		for(Medicine m : medicineList) {
			MedicineModel model = new MedicineModel();
			model.setMid(m.getMid());
			model.setMedicineName(m.getMedicineName());
			model.setPrice(m.getPrice());
			model.setStock(m.getStock());
			medicineModel.add(model);
		}
		logger.info("getAllMedicine() method ends()");
		return medicineModel;
		}
	
}

//public Medicine getMedicineById(int mid) throws MedicineNotFoundException{
//Medicine medicine=medicineRepository.findById(mid).orElse(null);
//if(medicine==null)
//	throw new MedicineNotFoundException("Medicine Not Found");
//return medicine;
//}

//public List<Medicine> getAllMedicine(){
//List<Medicine>medicineList=medicineRepository.findAll();
//return medicineList;
//}
//	public Medicine deleteByMedicineName(Medicine medicineName){
//	logger.info("deleting medicineName()....");
//	return medicineRepository.deleteByMedicineName(medicineName);
//}

