package com.example.MedicineManagementSystemdemo.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.MedicineManagementSystemdemo.entity.Ordered;


@Repository
public interface OrderedRepository extends JpaRepository<Ordered,Integer> {

	
      
	@Query(value="select o from Ordered o where o.deliveryDate=:date")
	List<Ordered> findAllOrderedByDate(LocalDate date);
	
	
    @Query(value="SELECT o FROM Ordered o JOIN o.customer c WHERE c.customerName IN :customerName")
	List<Ordered> findAllOrderedByCustomerName(String customerName);

    @Query(value="SELECT o FROM Ordered o JOIN o.customer c WHERE c.customerId IN :customerId")
	List<Ordered> findAllOrderedByCustomerId(int customerId);


	Ordered deleteByOrderId(int orderId);


	//Optional<Ordered> viewByMedicineName(String medicineName);

//	Optional<Ordered> viewByMedicineName(String medicineName);
   
}
	


