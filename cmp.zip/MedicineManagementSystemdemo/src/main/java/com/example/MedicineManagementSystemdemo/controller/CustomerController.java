package com.example.MedicineManagementSystemdemo.controller;



import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MedicineManagementSystemdemo.entity.Customer;
import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.model.CustomerInputModel;
import com.example.MedicineManagementSystemdemo.model.CustomerModel;
import com.example.MedicineManagementSystemdemo.model.CustomerOutputModel;
import com.example.MedicineManagementSystemdemo.service.CustomerService;


@RestController
@CrossOrigin("http://localhost:3000/")
public class CustomerController {
	
	private final Logger logger=LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;
	
	@GetMapping(value="/getallcustomer")
	public List<CustomerModel> getAllCustomer(){
		logger.info("Getting all customers");
		return customerService.getAllCustomer();
	}

	@GetMapping(value="/searchcustomerbyid/{id}")
	public CustomerOutputModel searchCustomerById(@PathVariable("id") int customerId) throws CustomerNotFoundException {
     logger.info("Searching Customer");
	return customerService.searchCustomerById(customerId);

	}

	@PostMapping(value ="/addcustomer")
	public Customer addCustomer(@RequestBody CustomerInputModel customerInputModel) {
		logger.info("Adding customer");
		Customer customer=customerService.addCustomer(customerInputModel);
		logger.info("customer added");
		return customer;
	}
	

	
	@DeleteMapping("/deletecustomerbyid/{id}")
	public List<Customer> deleteCustomerByIdAndReturnList(@PathVariable("id") int customerId) {
		   logger.info("deleting customerId");
	       List<Customer> customer = customerService.deleteCustomerByIdAndReturnList(customerId);
	       logger.info("Returing list");
	       return customer;
	    }
	    
}

//@GetMapping(value="/getcustomerbymedicineid/{mid}")
//public List<Customer> getCustomerByMedicineId(@PathVariable("mid") int mid) throws CustomerNotFoundException{
//	logger.info("Listing all Customers");
//	return customerService.getCustomerByMedicineId(mid);
//}
//
//@GetMapping(value="/getcustomerbyname/{name}")
//public Customer getCustomerByName(@PathVariable("name")String customerName) throws CustomerNotFoundException{
//	logger.info("Getting all Customer by medicineName");
//	return(Customer)customerService.getCustomerByName(customerName);
//}
//

