package com.example.MedicineManagementSystemdemo.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MedicineManagementSystemdemo.entity.Customer;
import com.example.MedicineManagementSystemdemo.entity.Ordered;
import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.model.CustomerInputModel;
import com.example.MedicineManagementSystemdemo.model.CustomerModel;
import com.example.MedicineManagementSystemdemo.model.CustomerOutputModel;
import com.example.MedicineManagementSystemdemo.repository.CustomerRepository;


import jakarta.transaction.Transactional;

@Service
public class CustomerService {
	
	private final Logger logger=LoggerFactory.getLogger(CustomerService.class);
	
	@Autowired
    CustomerRepository customerRepository;
	

	public Customer addCustomer(CustomerInputModel customerInputModel){
		logger.info("addCustomer() method starts");
		
		Customer customer =  new Customer();
		customer.setCustomerId(customerInputModel.getCustomerId());
		customer.setCustomerName(customerInputModel.getCustomerName());
		customer.setEmail(customerInputModel.getEmail());
		customer.setAddress(customerInputModel.getAddress());
		customer=customerRepository.save(customer);
		logger.info("addcustomer() method ends"); 
	    return customer;
	}
	
	public List<CustomerModel> getAllCustomer(){
		 logger.info("getAllCustomer() method starts");
		List<Customer> customerList=customerRepository.findAll();
		logger.info("customer{} ", customerList.size());
		List<CustomerModel> list= new ArrayList<>();
		for(Customer c:customerList) {
			CustomerModel customerModel=new CustomerModel();
			customerModel.setCustomerId(c.getCustomerId());
			customerModel.setCustomerName(c.getCustomerName());
			customerModel.setEmail(c.getEmail());
			customerModel.setAddress(c.getAddress());
			list.add(customerModel);
			}
		    logger.info("getAllCustomer() method ends");
			return list;
	}
	

    @Transactional
    public List<Customer> deleteCustomerByIdAndReturnList(int customerId) {
		logger.info("deleting customerId");
        customerRepository.deleteById(customerId);
        logger.info("deleted!");
        return customerRepository.findAll();
    }
	
	public CustomerOutputModel searchCustomerById(int id) throws CustomerNotFoundException { //get
		  Customer customer= customerRepository.findById(id).orElse(null);
		  if(customer==null) 
		   throw new CustomerNotFoundException("Customer not Found");
		  //return customer;
		  CustomerOutputModel model=new CustomerOutputModel();
		  model.setCustomerId(customer.getCustomerId());
		  model.setCustomerName(customer.getCustomerName());
		  model.setEmail(customer.getEmail());
		  model.setAddress(customer.getAddress());

		 return model;
	}

}

//public Customer getCustomerByName(String customerName) throws CustomerNotFoundException {
//logger.info("getCustomerByName() method starts");
//Customer customer= customerRepository.getCustomerByName(customerName);
//if(customer==null)
//{
//	logger.error("Customer not found : {}", customerName);
//	throw new CustomerNotFoundException(" Customer not  found");
//}
//	logger.info("getCustomerByName() method ends");
//return customer;
//}
//
//
//public List<Customer> getCustomerByMedicineId(int mid) throws CustomerNotFoundException {
//logger.info("getCustomerByMedicineId() method starts");
//List<Customer> customerList= customerRepository.getCustomerByMedicineId(mid);
//if(customerList.size()==0)
//{
//	logger.error("Customers are not found : {}", mid);
//    throw new CustomerNotFoundException(" Customer Not Found");
//}
//	logger.info("getCustomerByMedicineId() method ends");
//return customerList;
//}
