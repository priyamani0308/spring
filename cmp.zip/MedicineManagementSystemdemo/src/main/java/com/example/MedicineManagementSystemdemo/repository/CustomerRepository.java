package com.example.MedicineManagementSystemdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.MedicineManagementSystemdemo.entity.Customer;
import com.example.MedicineManagementSystemdemo.model.CustomerModel;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer>{

	

	 //Customer save(Customer customer);

//	List<Customer> findAll();
//
//	@Query(value ="select c from Customer c where c.customerName=:customerName")
//	Customer getCustomerByName(String customerName);
//
//	
//
//	Object findById(int customerId);
// 
//	@Query(value="SELECT c FROM Customer c JOIN c.medicine m WHERE m.mid IN :mid")
//	List<Customer> getCustomerByMedicineId(int mid);
//
//	void deleteById(int customerId);
//	
    @Query(value="select c from Customer c where c.customerId=:customerId")
	CustomerModel searchCustomerById(int customerId);
	
 
	


	

}

