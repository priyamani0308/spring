package com.example.MedicineManagementSystemdemo.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MedicineManagementSystemdemo.entity.Ordered;
import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.MedicineNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.OrderNotFoundException;
import com.example.MedicineManagementSystemdemo.model.OrderOutputModel;
import com.example.MedicineManagementSystemdemo.model.OrderedModel;
import com.example.MedicineManagementSystemdemo.service.CustomerService;
import com.example.MedicineManagementSystemdemo.service.OrderedService;


@RestController
public class OrderedController {
	
	private final Logger logger=LoggerFactory.getLogger(OrderedController.class);
	
	@Autowired
	OrderedService orderedService;
	
	@PostMapping(value="/createOrder")
	public Ordered createOrder(@RequestBody OrderedModel orderModel) throws MedicineNotFoundException, OrderNotFoundException, CustomerNotFoundException
	{
		Ordered order=null;
		order=orderedService.createOrder(orderModel);
		return order;
	
	}
		  
	@GetMapping(value="/getallordered")
	public List<OrderOutputModel> getAllOrdered() {
		logger.info("Retriving All the Orderes");
		return orderedService.getAllOrdered();
	    }

	@GetMapping(value="/searchorderbyid/{id}")
	public OrderOutputModel searchById(@PathVariable int id) throws OrderNotFoundException 
	{
		logger.info("searchById() method fetching values");
		return orderedService.searchById(id);
		
	}
	@DeleteMapping(value="/deletebyorderid/{orderid}")
	public Ordered deleteByOrderId(@PathVariable("orderid") int orderId){
		logger.info("deleteByOrderId() method");
		return orderedService.deleteByOrderId(orderId);
	}
}

//
//@GetMapping(value="findallorderedbydate/{date}")
//public List<OrderedModel> findAllOrderedByDate(@PathVariable  @DateTimeFormat(pattern = "yyyy-MM-dd")  LocalDate date) throws  OrderNotFoundException {
//	logger.info("Getting Orders by Date:{}",date);
//	List<OrderedModel> orderedList=orderedService.findAllOrderedByDate(date);
//	logger.info("Orderd Medicines in the  Date:{}",date);
//	return orderedList;
//}
//@GetMapping(value="findallorderedbycustomername/{customername}")
//public List<Ordered> findAllOrderedByCustomerName(@PathVariable ("customerName") String customerName) throws CustomerNotFoundException
//{
//	logger.info("findAllOrderByCustomerName() method starts");
// List<Ordered> orderedList=orderedService.findAllOrderedByCustomerName(customerName);
// logger.info("findAllOrderByCustomerName() method ends");
//	return orderedService.findAllOrderedByCustomerName(customerName);
//
//}
//@GetMapping(value="findallorderedbycustomerid/{customerid}")
//public List<Ordered> findAllOrderedByCustomerId(@PathVariable ("customerid") int customerId) throws CustomerNotFoundException
//{
//	logger.info("findAllOrderByCustomerId() method starts");
//	List<Ordered> orderedList=orderedService.findAllOrderedByCustomerId(customerId);
//	logger.info("findAllOrderByCustomerName() method ends");
//	return orderedService.findAllOrderedByCustomerId(customerId);
//
//}