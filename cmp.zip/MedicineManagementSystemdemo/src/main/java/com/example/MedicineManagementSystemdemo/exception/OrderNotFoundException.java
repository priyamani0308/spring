package com.example.MedicineManagementSystemdemo.exception;



public class OrderNotFoundException extends Exception {

	public OrderNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}

