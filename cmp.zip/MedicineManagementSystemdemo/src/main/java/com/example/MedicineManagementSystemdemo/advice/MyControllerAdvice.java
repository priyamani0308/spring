package com.example.MedicineManagementSystemdemo.advice;


import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.MedicineNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.OrderNotFoundException;
import com.example.MedicineManagementSystemdemo.model.ApiResponseError;



@ControllerAdvice
public class MyControllerAdvice extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value = CustomerNotFoundException.class)
	public ResponseEntity<ApiResponseError> handleCustomerNotFoundException(CustomerNotFoundException ex,
			WebRequest request) {
		ApiResponseError obj = new ApiResponseError();
		obj.setMessage(ex.getMessage());
		obj.setStatusCode("404");
	    obj.setTimeStamp(LocalDateTime.now());
		return new ResponseEntity<>(obj, HttpStatus.NOT_FOUND);

	}

@ExceptionHandler(value = MedicineNotFoundException.class)
public ResponseEntity<ApiResponseError> handleMedicineNotFoundException(MedicineNotFoundException ex, 
		WebRequest request){
         ApiResponseError obj = new ApiResponseError();
        obj.setMessage(ex.getMessage());
        obj.setStatusCode("404");
        obj.setTimeStamp(LocalDateTime.now());
        return new ResponseEntity<>(obj, HttpStatus.NOT_FOUND);
}


@ExceptionHandler(value = OrderNotFoundException.class)
public ResponseEntity<ApiResponseError> handleOrderNotFoundException(OrderNotFoundException ex, 
		WebRequest request){
         ApiResponseError obj = new ApiResponseError();
        obj.setMessage(ex.getMessage());
        obj.setStatusCode("404");
        obj.setTimeStamp(LocalDateTime.now());
        return new ResponseEntity<>(obj, HttpStatus.NOT_FOUND);
}
}


