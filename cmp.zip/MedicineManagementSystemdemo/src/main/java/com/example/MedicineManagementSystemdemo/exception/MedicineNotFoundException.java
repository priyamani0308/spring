package com.example.MedicineManagementSystemdemo.exception;



public class MedicineNotFoundException extends Exception {

	public MedicineNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}

