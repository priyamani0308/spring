package com.example.MedicineManagementSystemdemo.service;



import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.MedicineManagementSystemdemo.entity.Customer;
import com.example.MedicineManagementSystemdemo.entity.Medicine;
import com.example.MedicineManagementSystemdemo.entity.Ordered;
import com.example.MedicineManagementSystemdemo.exception.CustomerNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.MedicineNotFoundException;
import com.example.MedicineManagementSystemdemo.exception.OrderNotFoundException;
import com.example.MedicineManagementSystemdemo.model.CustomerModel;
import com.example.MedicineManagementSystemdemo.model.CustomerOutputModel;
import com.example.MedicineManagementSystemdemo.model.MedicineModel;
import com.example.MedicineManagementSystemdemo.model.OrderOutputModel;
import com.example.MedicineManagementSystemdemo.model.OrderedModel;
import com.example.MedicineManagementSystemdemo.repository.OrderedRepository;

import jakarta.transaction.Transactional;



@Service
public class OrderedService {
	
	private final Logger logger=LoggerFactory.getLogger(OrderedService.class);
	
	@Autowired
	OrderedRepository orderedRepository;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	MedicineService medicineService;


	
	@Transactional
	 public Ordered createOrder(OrderedModel orderModel) throws MedicineNotFoundException, OrderNotFoundException, CustomerNotFoundException{
	  
	  MedicineModel medicine =medicineService.viewMedicineById(orderModel.getMid());
	  CustomerOutputModel customer =customerService.searchCustomerById(orderModel.getCustomerId());
	  
	  if(orderModel.getOrderType().equalsIgnoreCase("sale")) {
	   if(medicine.getStock()-orderModel.getQuantity()<0) {
	    throw new OrderNotFoundException("Stock is insufficient");
		
	   }
	   Ordered order = new Ordered();
	   order.setPrice(orderModel.getQuantity()*medicine.getPrice());
	   Customer c= new Customer();
	   c.setCustomerId(customer.getCustomerId());
	   order.setCustomer(c);
	   Medicine m = new Medicine();
	   m.setMid(medicine.getMid());
	   order.setMedicine(m);
	   order.setQuantity(orderModel.getQuantity());
	   order.setOrderedDate(LocalDate.now());
	   order.setOrderType(orderModel.getOrderType());
	   order.setDeliveryDate(LocalDate.now());
	   order=orderedRepository.save(order);
	   
	   medicineService.updateStock(orderModel.getMid(),medicine.getStock()-orderModel.getQuantity());
	   return order;
	  }
	  else {
	   Ordered order = new Ordered();
	   order.setPrice(orderModel.getQuantity()*medicine.getPrice());
	   Customer c= new Customer();
	   c.setCustomerId(customer.getCustomerId());
	   order.setCustomer(c);
	   Medicine m = new Medicine();
	   m.setMid(medicine.getMid());
	   order.setMedicine(m);
	   order.setQuantity(orderModel.getQuantity());
	   order.setOrderedDate(LocalDate.now());
	   order.setOrderType(orderModel.getOrderType());
	   order.setDeliveryDate(LocalDate.now());
	   order=orderedRepository.save(order);
	   
	   medicineService.updateStock(orderModel.getMid(),medicine.getStock()+orderModel.getQuantity());
	   return order;
	  }
	   
	}
	 
	 
	 public List<OrderOutputModel> getAllOrdered() {
			logger.info("getAllOrdered() method starts");
			List<Ordered> orderedlist = orderedRepository.findAll();
			List<OrderOutputModel> list = new ArrayList<>();
			for (Ordered o : orderedlist) {
				OrderOutputModel model=new OrderOutputModel(); 
				model.setOrderId(o.getOrderId());
				model.setPrice(o.getPrice());
				model.setQuantity(o.getQuantity());
				model.setDeliveryDate(o.getDeliveryDate());
				model.setOrderType(o.getOrderType());
				model.setCustomerId(o.getCustomer().getCustomerId());
				model.setMid(o.getMedicine().getMid());
				list.add(model);
			}
			logger.info("ordered{}", orderedlist.size());
			logger.info("getAllOrdered() method ends");
			return list;
	 }
			
	 public OrderOutputModel searchById(int id) throws OrderNotFoundException 
		{
			logger.info(" searchById()  method starts()");
			Ordered order=orderedRepository.findById(id).orElse(null);
			if(order==null)
				throw new OrderNotFoundException("Order not found");
			logger.error("Order not found in the  id: {}", id);	
			OrderOutputModel model=new OrderOutputModel(); 
			model.setOrderId(order.getOrderId());
	        model.setPrice(order.getPrice());
	        model.setQuantity(order.getQuantity());
			model.setDeliveryDate(order.getDeliveryDate());
			model.setOrderType(order.getOrderType());
			model.setCustomerId(order.getCustomer().getCustomerId());
			model.setMid(order.getMedicine().getMid());
			logger.info(" searchById()  method ends()");
			return model;
			
		}
	 
	 public Ordered deleteByOrderId(int orderId)
	 {
			logger.info(" OrderId deleted");
			return orderedRepository.deleteByOrderId(orderId);
	 }
		
	
}	   
	   
	  

	


//	public List<OrderedModel> findAllOrderedByDate(LocalDate date) throws OrderNotFoundException {
//		logger.info("findAllOrderedByDate() method starts");
//		List<Ordered> orderedList = orderedRepository.findAllOrderedByDate(date);
//		if (orderedList == null) {
//			logger.error("Order not found in the  date: {}", date);
//			throw new OrderNotFoundException("No Order");
//		}
//		List<OrderedModel> list = new ArrayList<>();
//		for (Ordered o : orderedList) {
//			OrderedModel orderedModel = new OrderedModel();
//			orderedModel.setOrderId(o.getOrderId());
//			orderedModel.setDeliveryDate(o.getDeliveryDate());
//			orderedModel.setStatus(o.getStatus());
//			orderedModel.setCustomerId(o.getCustomer().getCustomerId());
//			list.add(orderedModel);
//		}
//		logger.info("order{}", orderedList.size());
//		logger.info("findAllOrderedByDate() method ends");
//		return list;
//	}
//	
//	
//	public List<Ordered> findAllOrderedByCustomerName(String customerName) throws CustomerNotFoundException
//	{
//		    logger.info(" findAllOrderedByCustomerName()  method starts()");
//		List<Ordered> orderedList=orderedRepository.findAllOrderedByCustomerName(customerName);
//		if(orderedList==null)
//			throw new CustomerNotFoundException("No order found");
//			logger.info(" findAllOrderedByCustomerName()  method ends()");
//		   return orderedList;
//		
//	}
//	
//	public List<Ordered> findAllOrderedByCustomerId(int customerId) throws CustomerNotFoundException
//	{
//		logger.info(" findAllOrderedByCustomerId()  method starts()");
//		List<Ordered> orderedList=orderedRepository.findAllOrderedByCustomerId(customerId);
//		if(orderedList==null)
//			throw new CustomerNotFoundException("No order found!");
//		logger.info(" findAllOrderedByCustomerId()  method ends()");
//		return orderedList;
//		
//	}
//	


	
	   
	
	



